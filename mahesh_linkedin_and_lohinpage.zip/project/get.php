<!DOCTYPE html>
<html lang="en">
<head>
  <title>Login with Facebook</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  
  <link href="style.css" rel="stylesheet">
  
</head>
<body>
<br>
<br>
<!-- NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN -->
<!--  If the user is login  -->
<?php if(isset($_SESSION['fb_user_id'])): ?>
    

    <div class="container" style="margin-top:30px">
      <div class="row">
        <div class="col-sm-2">
          <h2>About Me</h2>
          <h5>Profile Picture:</h5>
          <div class="fakeimg"><?php echo  $_SESSION['fb_user_pic']; ?></div>
          <hr class="d-sm-none">
        </div>
        <div class="col-sm-2"></div>
        <div class="col-sm-8">


          <h3>User Info</h3>
          <ul class="nav nav-pills flex-column">
            <li class="nav-item">
              <a>Facebook ID: <?php echo  $_SESSION['fb_user_id']; ?></a>
            </li>
            <li class="nav-item">
              <a>Full Name: <?php echo $_SESSION['fb_user_name']; ?></a>
            </li>
            <li class="nav-item">
              <a>Email: <?php echo $_SESSION['fb_user_email']; ?></a>
            </li>
          </ul>
    
  <a href="fb_logout.php">Logout</a>
   
          
        </div>
      </div>
    </div>
<!-- NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN -->
<!-- if user not login -->
<?php else: ?>

    <div class="login-form">
<center>
            <div class="text-center social-btn">
                <a href="index_linkedin.php" class="btn btn-outline-secondary btn-block style="background-color:" "><img src="https://img.icons8.com/3d-fluency/100/000000/3d-fluency-linkedin-logo.png" height=30px/></i>    Sign in with <b>LinkedIn</b></a>
            </div>
    </div>
<?php endif ?>
<!-- NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN -->
      
</body>
</html>
