<?php

//config.php

//Include Google Client Library for PHP autoload file
require_once 'gg/vendor/autoload.php';

//Make object of Google API Client for call Google API
$google_client = new Google_Client();

//Set the OAuth 2.0 Client ID
$google_client->setClientId('35036132024-go193uuo194jmoo0o4390acel2u4efp5.apps.googleusercontent.com');

//Set the OAuth 2.0 Client Secret key
$google_client->setClientSecret('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');

//Set the OAuth 2.0 Redirect URI
$google_client->setRedirectUri('http://localhost/project/index.php');

//
$google_client->addScope('email');

$google_client->addScope('profile');
//start session on web page
if(!isset($_SESSION))
    {
        session_start();
    }
?>
