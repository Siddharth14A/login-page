
<?php
require_once 'vendor/autoload.php';
 
$config = [
    'callback' => 'http://localhost/project/index_linkedin.php',
    'keys'     => [
                    'id' => '86qjb1uon4lil3',
                    'secret' => 'DQrSajWUJPTPOcqC'
                ],
    'scope'    => 'r_liteprofile r_emailaddress',
];
 
$adapter = new Hybridauth\Provider\LinkedIn( $config );
