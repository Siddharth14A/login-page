<?php
 
require_once 'fb_config.php';

$permissions = ['email'];

if (isset($accessToken))
{
	if (!isset($_SESSION['facebook_access_token'])) 
	{
		//get short-lived access token
		$_SESSION['facebook_access_token'] = (string) $accessToken;
		
		//OAuth 2.0 client handler
		$oAuth2Client = $fb->getOAuth2Client();
		
		//Exchanges a short-lived access token for a long-lived one
		$longLivedAccessToken = $oAuth2Client->getLongLivedAccessToken($_SESSION['facebook_access_token']);
		$_SESSION['facebook_access_token'] = (string) $longLivedAccessToken;
		
		//setting default access token to be used in script
		$fb->setDefaultAccessToken($_SESSION['facebook_access_token']);
	} 
	else 
	{
		$fb->setDefaultAccessToken($_SESSION['facebook_access_token']);
	}
	
	
	//redirect the user to the index page if it has $_GET['code']
	if (isset($_GET['code'])) 
	{
		header('Location: ./');
	}
	
	
	try {
		$fb_response = $fb->get('/me?fields=name,first_name,last_name,email');
		$fb_response_picture = $fb->get('/me/picture?redirect=false&height=200');
		
		$fb_user = $fb_response->getGraphUser();
		$picture = $fb_response_picture->getGraphUser();
		
		$_SESSION['fb_user_id'] = $fb_user->getProperty('id');
		$_SESSION['fb_user_name'] = $fb_user->getProperty('name');
		$_SESSION['fb_user_email'] = $fb_user->getProperty('email');
		$_SESSION['fb_user_pic'] = $fb_user->getProperty('');
		
		
	} catch(Facebook\Exceptions\FacebookResponseException $e) {
		echo 'Facebook API Error: ' . $e->getMessage();
		session_destroy();
		// redirecting user back to app login page
		header("Location: ./");
		exit;
	} catch(Facebook\Exceptions\FacebookSDKException $e) {
		echo 'Facebook SDK Error: ' . $e->getMessage();
		exit;
	}
} 
else 
{	
	// replace your website URL same as added in the developers.Facebook.com/apps e.g. if you used http instead of https and you used
	$fb_login_url = $fb_helper->getLoginUrl('http://localhost/project/', $permissions);
    
    if(isset($linkedin_login_url))
    {
        header("Location:linkedin/li_linkedin.php");
     exit();
    }
    
    
}

?>
<?php
$host="localhost";
$user="root";
$password="";
$db="login";
$conn=mysqli_connect($host,$user,$password,$db);
if(isset($_POST['Username'])){
    
    $uname=$_POST['Username'];
    $password=$_POST['Password'];
    
    $result=mysqli_query($conn,"select * from login_details where Username='".$uname."' AND Password='".$password."' LIMIT 1")
    or die("failed connect database".mysqli_error());
    $row=mysqli_fetch_array($result);
    if($row['Username']==$uname && $row['Password']==$password)
    {
    #if(mysqli_num_rows($result)==1){
       header("Location:otp.php");
        exit();
        
    }
    else{
        echo " You Have Entered Incorrect Password";
        exit();
   }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Login with Facebook</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<link href="style.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="btn btn-link" href="https://mikhvision.com">Home <span class="sr-only">(current)</span></a>
      </li>
<li class="nav-item">
  <a class="nav-link" href="https://mikhvision.com/contact-us/"> Contact Us</a>
</li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Our Services
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
       <a class="dropdown-item" href="https://mikhtech.com"><img src="https://img.icons8.com/office/16/000000/laptop.png" height="22px"/> MIKH Tech</a><br>
<a class="dropdown-item" href="#"><img src="https://img.icons8.com/fluency/48/000000/pen.png" height ="22px"/> MIKH Media</a><br>
       <a class="dropdown-item" href="https://mikhhost.in"><img src="https://img.icons8.com/ios/50/000000/cloud.png" height="22px"/> MIKH Host</a><br>
      <a class="dropdown-item" href="https://mikhteach.in"><img src="https://img.icons8.com/color/48/000000/teacher.png" height="22px"/> MIKH Teach</a><br>
       <a class="dropdown-item" href="#"><img src="https://img.icons8.com/external-flaticons-flat-flat-icons/64/000000/external-mechanisms-automation-technology-flaticons-flat-flat-icons.png" height="22px"/> MIKHTRONICS</a>
      
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="https://mikhvision.com/about-us/">About Us</a>
        </div>
      </li>

    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-dark my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>
<br>
<!-- NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN --> 
<!--  If the user is login  -->
<?php if(isset($_SESSION['fb_user_id'])): ?>
<div class="container" style="margin-top:30px">
	  <div class="row">
		<div class="col-sm-5">
		  <h2>About Me</h2>
		  <h5>Profile Picture:</h5>
		  <div class="fakeimg"><?php echo  $_SESSION['fb_user_pic']; ?></div>
		  <hr class="d-sm-none">
		</div>
		<div class="col-sm-2"></div>
		<div class="col-sm-8">


		  <h3>User Info</h3>
		  <ul class="nav nav-pills flex-column">
			<li class="nav-item">
			  <a>Facebook ID: <?php echo  $_SESSION['fb_user_id']; ?></a>
			</li>
			<li class="nav-item">
			  <a>Full Name: <?php echo $_SESSION['fb_user_name']; ?></a>
			</li>
			<li class="nav-item">
			  <a>Email: <?php echo $_SESSION['fb_user_email']; ?></a>
			</li>
		  </ul>
    
  <a href="fb_logout.php">Logout</a>
   
		  
		</div>
	  </div>
	</div>
<!-- NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN --> 
<!-- if user not login -->
<?php else: ?>

	<div class="login-form">
<br>
    <form action="" method="post">
			<div class="text-center social-btn">
				<a href="<?php echo $fb_login_url;?>" class="btn btn-outline-primary btn-block"><img src="https://img.icons8.com/color/144/000000/facebook-new.png" height=30px/>        Sign in with Facebook</a>
			</div>


<div class="text-center social-btn">
    <a href="ms_signin.php" class="btn btn-outline-dark btn-block style="background-color:"red"><img src="https://img.icons8.com/color/48/000000/microsoft.png"height=30px/>    Sign in with Microsoft</a>
</div>


<div class="text-center social-btn">
<a href="<?php echo $google_login;?>" class="btn btn-outline-danger btn-block rounded"><img src="https://img.icons8.com/fluency/100/000000/google-plus-circled.png" height=30px/></i>  Sign in with Google</a>
</div>


<div class="text-center social-btn">
                <a href="index_linkedin.php" class="btn btn-outline-secondary btn-block style="background-color:" "><img src="https://img.icons8.com/color/240/000000/linkedin.png" height=30px/></i>    Sign in with LinkedIn</a>
            </div>


<div class="or-seperator"><i>or</i></div>
			<div class="form-group">
				<div class="input-group">                
					<div class="input-group-prepend">
						<span class="input-group-text"><span class="fa fa-user"></span></span>                    
					</div>


<input type="text" class="form-control" name="Username" placeholder="Username">
				</div>
			</div>
			<div class="form-group">
				<div class="input-group">
					<div class="input-group-prepend">
						<span class="input-group-text"><i class="fa fa-lock"></i></span>                    
					</div>
					<input type="password" class="form-control" name="Password" placeholder="Password">
				</div>
			</div>        
			<div class="form-group">
				<input type="submit" value="Sign In" class="btn btn-info btn-block login-btn" onclick="location.href='otp.php'"/>
</form>
			</div>
			<div class="clearfix">
				<label class="float-left form-check-label"><input type="checkbox"> Remember me</label>
				<a href="rec.php" class="float-right text-danger">Forgot Password?</a>
			</div>  
			
		</form>
<br>
		<div class="hint-text">Don't have an account? <a href="ins.php" class="text-info">Register Now!</a></div>
	</div>
<?php endif ?>
</body>
</html>
