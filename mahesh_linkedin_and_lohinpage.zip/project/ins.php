<?php
$host="localhost";
$user="root";
$password="";
$db="login";
$conn=mysqli_connect($host,$user,$password,$db);
if(isset($_POST['Fullname']))
{
    $name1=$_POST['Fullname'];
    $name2=$_POST['Username'];
    $name3=$_POST['Password'];
    $mail_id=$_POST['Email'];
    $ph=$_POST['Phone'];
    
    $result=mysqli_query($conn,"insert into login_details values('$name1','$name2','$name3','$mail_id', $ph)")
    or die("failed connect database".mysqli_error($conn));
    if(! $result)
    {
        die('Could not enter data: ' . mysql_error());
    }
    else{
    echo "Entered data successfully\n";
    echo "THANK YOU";
    exit();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>insert page</title>
</head>
<body>
    <div class="container">
    <p><h1><center> Add your details to register</h1></p>
    <form method="POST" style="position: absolute; left: 5%; top: 20%;">

        <div class="form-input">
        Full Name:<input type="text" name="Fullname" >
        </div><br><br>

<div class="form-input">
User name:<input type="text" name="Username" >
</div><br><br>

<div class="form-input">
Password:<input type="text" name="Password" >
</div><br><br>

         <div class="form-input">
         Email:<input type="text" name="Email" >
        </div><br><br>

        <div class="form-input">
        Phone number:<input type="number" name="Phone" >
        </div><br><br>

        

<div class="text-center social-btn">
        <input type="submit" value="create" class="btn-login">
    </form>
</body>
</html>
