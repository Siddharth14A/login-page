<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Login with Facebook</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  
  <link href="style.css" rel="stylesheet">
  
</head>
<body>
<br>
<br>
<CENTER><h2>Enter your phone number to change password<h2>
<br>
	<div class="login-form">
		<form action="" method="post">
			

			
			<div class="form-group">
				<div class="input-group">                
					<div class="input-group-prepend">
						<span class="input-group-text"><span class="fa fa-user"></span></span>                    
					</div>
					<input type="number" class="form-control" name="username" placeholder="PHONE">
				</div>
			</div>
			        
			<center><div class="form-group">
				<button type="submit" class="btn btn-outline-primary btn-sm login-btn">Send OTP</button>
			</div>
<div class="form-group">
    <div class="input-group">
        <div class="input-group-prepend">
            <span class="input-group-text"><span class="fa fa-user"></span></span>
        </div>
        <input type="text" class="form-control" name="username" placeholder="OTP">
    </div>
</div>
        
<div class="form-group">
    <input type="submit" value="Verify" class="btn btn-success btn-block login-btn">
</div>
		</form>
</body>
</html>
