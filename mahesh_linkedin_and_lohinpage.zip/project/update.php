<?php
$host="localhost";
$user="root";
$password="";
$db="login";
$conn=mysqli_connect($host,$user,$password,$db);
if(isset($_POST['Password']))
{
    $name=$_POST['Password'];
    $ph_no=$_POST['Phone'];

    $result=mysqli_query($conn,"UPDATE login_details SET name='".$name."' WHERE phone='".$ph_no."'")
    or die("failed connect database".mysqli_error());
    if(! $result)
    {
        die('Could not updated data: ' . mysql_error());
    }
    else{
    echo "Updated data successfully\n";
    echo "THANKK YOU";
    exit();
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>update page</title>
</head>
<body>
<center><h1>UPDATE CUSTOMER DETAILS</h1>
    <div class="container">
    <form method="POST" style="position: absolute;top: 20%;">
        
<div class="form-input">
Enter Your new password:<input type="text" name="Password">
</div><br><br>
        
<div class="form-input">
Enter Phone number:<input type="number" name="Phone">
</div><br><br>
        
<input type="submit" value="update"class="btn-login">
</p>
</form>
</body>
</html>

