<?php
require_once 'config_linkedin.php';
 
try {
    if ($adapter->isConnected()) {
        $adapter->disconnect();
     }
}
catch( Exception $e ){
    echo $e->getMessage() ;
}
?>
<html>
<head>
</head>
<body>
User logged out
<div>
<a href="http://localhost/project/index.php">Go Back to home page
</div>
</body>
</html>

