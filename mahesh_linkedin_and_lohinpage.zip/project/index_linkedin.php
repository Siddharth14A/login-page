<?php
require_once 'config_linkedin.php';
 
try {
    $adapter->authenticate();
    $userProfile = $adapter->getUserProfile();
    echo "Hello ".$userProfile->lastName."<br>";
    echo "<img src=".$userProfile->photoURL." style=width:100px;height:100px;><br>";
    echo "Name :".$userProfile->displayName."<br>";
    echo "Email :".$userProfile->email."<br>";
}
catch( Exception $e ){
    echo $e->getMessage() ;
}
?>
<html>
    <head><title>Linkedin Page</title>
<body><br><br>
<a href="logout_linkedin.php">Logout</a>
<body>
</head>
</html>
